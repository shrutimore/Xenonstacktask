1. create a superuser using command
python manage.py createsuperuser
enter mail, pass etc.

existing mail to login: admin@gmail.com
password: admin123

2. Run project using command 
python manage.py runserver

3. Enter mail id and pass login

4. CRUD Operations with Django 
Create a course, session, subject, staff, student etc  

Total Apps
 hod_views.py
 student views.py
 staff_views.py
 EmailBackend.py
 EditResultView.py

Features
1. Data analysis dashboard
2. notifications
